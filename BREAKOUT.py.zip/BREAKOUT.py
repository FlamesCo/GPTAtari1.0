import pygame
import random

# Set up the screen
pygame.init()
win = pygame.display.set_mode((600, 800))
pygame.display.set_caption("Breakout Game")

# Create paddle
class Paddle(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((100, 20))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.x = 250
        self.rect.y = 780

    def move_left(self):
        self.rect.x -= 10

    def move_right(self):
        self.rect.x += 10

    def update(self, *args):
        if self.rect.x < 0:
            self.rect.x = 0
        if self.rect.x > 500:
            self.rect.x = 500

# Create ball
class Ball(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.x = 290
        self.rect.y = 390
        self.dx = 2
        self.dy = -2

    def update(self, *args):
        self.rect.x += self.dx
        self.rect.y += self.dy

        if self.rect.left < 0 or self.rect.right > win.get_width():
            self.dx *= -1

        if self.rect.top < 0:
            self.dy *= -1
        
        if self.rect.bottom > win.get_height():
            self.rect.x = 290
            self.rect.y = 390
            self.dy = -self.dy

# Create blocks
class Block(pygame.sprite.Sprite):
    def __init__(self, color, x, y):
        super().__init__()
        self.image = pygame.Surface((80, 20))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# Create groups
all_sprites = pygame.sprite.Group()
paddle = Paddle()
all_sprites.add(paddle)
ball = Ball()
all_sprites.add(ball)

blocks = pygame.sprite.Group()
colors = [(255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 128, 0), (0, 0, 255)]
for y in range(50, 251, 30):
    for x in range(0, 600, 100):
        block = Block(random.choice(colors), x, y)
        blocks.add(block)
        all_sprites.add(block)

# Set up game loop
clock = pygame.time.Clock()
running = True

while running:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        paddle.move_left()
    if keys[pygame.K_RIGHT]:
        paddle.move_right()

    # Check for collision with paddle
    if ball.rect.colliderect(paddle.rect):
        ball.dy = -ball.dy

    # Check for collision with blocks
    block_hit_list = pygame.sprite.spritecollide(ball, blocks, True)
    if len(block_hit_list) > 0:
        ball.dy = -ball.dy

    win.fill((0, 0, 0))
    all_sprites.update()
    all_sprites.draw(win)

    pygame.display.flip()

pygame
