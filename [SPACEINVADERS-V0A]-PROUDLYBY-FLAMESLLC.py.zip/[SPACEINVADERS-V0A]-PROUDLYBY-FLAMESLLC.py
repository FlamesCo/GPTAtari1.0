import pygame
import random

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Space Invaders")

# Load the player and enemy images
player_image = pygame.Surface((20, 20))
player_image.fill((255, 255, 255))
enemy_image = pygame.Surface((20, 20))
enemy_image.fill((255, 0, 0))

# Set up the player and enemies
player_x = screen_width / 2 - 10
player_y = screen_height - 50
player_speed = 5
enemy_speed = 2
enemy_rows = 5
enemy_cols = 10
enemies = []
for row in range(enemy_rows):
    for col in range(enemy_cols):
        enemy_x = 50 + col * 50
        enemy_y = 50 + row * 50
        enemies.append((enemy_x, enemy_y))

# Set up the bullets
bullet_width = 4
bullet_height = 10
bullet_speed = 7
player_bullet = None
enemy_bullet = None

# Set up the game loop
clock = pygame.time.Clock()
running = True
while running:
    clock.tick(60)
    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if not player_bullet:
                    player_bullet = pygame.Rect(player_x + 8, player_y - bullet_height, bullet_width, bullet_height)

    # Move the player
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_x > 0:
        player_x -= player_speed
    elif keys[pygame.K_RIGHT] and player_x < screen_width - 20:
        player_x += player_speed

    # Move the bullets
    if player_bullet:
        player_bullet.y -= bullet_speed
        if player_bullet.y < 0:
            player_bullet = None
    if enemy_bullet:
        enemy_bullet.y += bullet_speed
        if enemy_bullet.colliderect((player_x, player_y, 20, 20)):
            running = False
        if enemy_bullet.y > screen_height:
            enemy_bullet = None

    # Move the enemies
    for i, enemy in enumerate(enemies):
        enemy_x, enemy_y = enemy
        enemy_x += enemy_speed
        if enemy_x < 0 or enemy_x > screen_width - 20:
            enemy_speed = -enemy_speed
            for enemy in enemies:
                enemy_x, enemy_y = enemy
                enemy_y += 10
                enemy = (enemy_x, enemy_y)
        enemies[i] = (enemy_x, enemy_y)

    # Check for collisions
    for i, enemy in enumerate(enemies):
        enemy_rect = pygame.Rect(enemy[0], enemy[1], 20, 20)
        if player_bullet and player_bullet.colliderect(enemy_rect):
            enemies.pop(i)
            player_bullet = None
            break
        if enemy_bullet and enemy_rect.colliderect(enemy_bullet):
            enemies.pop(i)
            enemy_bullet = None
            break

    # Draw the screen
    screen.fill((0, 0, 0))
    for enemy in enemies:
        screen.blit(enemy_image, enemy)
    if player_bullet:
        pygame.draw.rect(screen, (255, 255, 255), player_bullet)
    screen.blit(player_image, (player_x, player_y))
    pygame.display.flip()

# Clean up
pygame.quit()